import random
from scipy.sparse import lil_matrix
from scipy.sparse import load_npz

from Properties import *


############################# QUESTION 3

def add_initial_edges(network, existing_nodes, degrees, probs):
    # print(probs)
    i, j = np.random.choice(existing_nodes, 2, replace=False, p=probs)

    while network[i, j] == 1:
        i, j = np.random.choice(existing_nodes, size=2, replace=False, p=probs)

    network[i, j] = 1
    network[j, i] = 1

    degrees[i] += 1
    degrees[j] += 1

    return network, degrees


def add_edge(network, nodes, k, m, probs, degrees):
    chosen_nodes = np.random.choice(nodes, size=m, replace=False, p=probs)

    for i in chosen_nodes:
        network[k, i] = 1
        network[i, k] = 1

        degrees[i] += 1
        degrees[k] += 1

    return network, degrees


##
# p: Possibility for preferential attachment e.g. p=1 is the same as tweak=False

def ba_model(n, m, m0=None, tweak=False, p=1.0):
    if m0 is None:
        m0 = m

    assert m <= m0

    network = lil_matrix((n, n))

    nodes = np.array([i for i in range(n)])
    node_probs = np.array([0.0 for i in range(n)])
    for i in range(m0):
        node_probs[i] = 1 / m0
    # print(node_probs)
    degrees = np.array([0 for i in range(n)])

    node_count = m0

    print('probs', node_probs)
    while degrees[:m0].min() < 1:  # create random graph with m0 nodes and every node degree at least 1
        network, degrees = add_initial_edges(network, nodes, degrees, node_probs)

    node_probs = degrees / degrees.sum()

    print(network)
    print(degrees)
    print(node_probs)

    print('Initializing done')
    cls = lambda: print('\n' * 100)

    while node_count < n:
        cls()
        print(100 * node_count / n)
        if tweak:
            uniform_probs = np.minimum(degrees, 1).astype(np.float)
            uniform_probs /= uniform_probs.sum()
            if random.uniform(0, 1) <= p:  # possibility of preferential attachment
                network, degrees = add_edge(network, nodes, k=node_count, m=m, probs=node_probs, degrees=degrees)
            else:
                network, degrees = add_edge(network, nodes, k=node_count, m=m, probs=uniform_probs, degrees=degrees)
        else:
            network, degrees = add_edge(network, nodes, k=node_count, m=m, probs=node_probs, degrees=degrees)

        node_probs = degrees / degrees.sum()
        node_count += 1

    print('Done!')
    return csr_matrix(network), degrees


###
# Dataset:  actor.edgelist  Nodes:  702387  Edges:  29397908  Mean K:  41.85428830544984
# Dataset:  citation.edgelist  Nodes:  449672  Edges:  4689361  Mean K:  10.428403369567151
# Dataset:  collaboration.edgelist  Nodes:  23132  Edges:  93439  Mean K:  4.039382673352931
# Dataset:  email.edgelist  Nodes:  57193  Edges:  103083  Mean K:  1.8023709195181228
# Dataset:  internet.edgelist  Nodes:  192243  Edges:  609066  Mean K:  3.168208985502723
# Dataset:  metabolic.edgelist  Nodes:  1038  Edges:  5802  Mean K:  5.589595375722543
# Dataset:  phonecalls.edgelist  Nodes:  36594  Edges:  91826  Mean K:  2.5093184675083346
# Dataset:  powergrid.edgelist  Nodes:  4940  Edges:  6594  Mean K:  1.3348178137651823
# Dataset:  protein.edgelist  Nodes:  2017  Edges:  2705  Mean K:  1.3411006445215667
# Dataset:  www.edgelist  Nodes:  325728  Edges:  1469679  Mean K:  4.511982390215149
###


# actor
# n = 702387
# actor_network, actor_degrees = ba_model(n, 41)
# save_npz('networks/actor.npz', actor_network)

# citation
# n = 449672
# citation_network, citation_degrees = ba_model(n, 10)
# save_npz('networks/citation.npz', citation_network)

# collaboration
# n = 23132
# collaboration_network, collaboration_degrees = ba_model(n, 4)
# save_npz('networks/collaboration.npz', collaboration_network)

# email
# n = 57193
# email_network, email_degrees = ba_model(n, 2)
# save_npz('networks/email.npz', email_network)

# internet
# n = 192243
# internet_network, internet_degrees = ba_model(n, 3)
# save_npz('networks/internet.npz', internet_network)

# metabolic
# n = 1038
# metabolic_network, metabolic_degrees = ba_model(n, 6)
# save_npz('networks/metabolic.npz', metabolic_network)

# phonecalls
# n = 36594
# phonecalls_network, phonecalls_degrees = ba_model(n, 2)
# save_npz('networks/phonecalls.npz', phonecalls_network)

# powergrid
# n = 4940
# powergrid_network, powergrid_degrees = ba_model(n, 2)
# save_npz('networks/powergrid.npz', powergrid_network)

# protein
# n = 2017
# protein_network, protein_degrees = ba_model(n, 2)
# save_npz('networks/protein.npz', protein_network)

# www
# n = 325728
# www_network, www_degrees = ba_model(n, 5)
# save_npz('networks/www.npz', www_network)

# BA without tweak
# n = 5000
# ba_wo_t_network, ba_wo_t_degrees = ba_model(n, 3)
# save_npz('networks/ba_without_tweak.npz', ba_wo_t_network)

# BA with tweak and p = 0.8
# n = 5000
# ba_t_network_8, ba_t_degrees_8 = ba_model(n, 3, tweak=True, p=0.8)
# save_npz('networks/ba_tweak_p08.npz', ba_t_network_8)


# BA with tweak and p = 0.6
# n = 5000
# ba_t_network_6, ba_t_degrees_6 = ba_model(n, 3, tweak=True, p=0.6)
# save_npz('networks/ba_tweak_p06.npz', ba_t_network_6)


# BA with tweak and p = 0.4
# n = 5000
# ba_t_network_4, ba_t_degrees_4 = ba_model(n, 3, tweak=True, p=0.4)
# save_npz('networks/ba_tweak_p04.npz', ba_t_network_4)
#
#
#
# BA with tweak and p = 0.2
# n = 5000
# ba_t_network_2, ba_t_degrees_2 = ba_model(n, 3, tweak=True, p=0.2)
# save_npz('networks/ba_tweak_p02.npz', ba_t_network_2)
#
#
#
# BA with tweak and p = 0.0
# n = 5000
# ba_t_network_0, ba_t_degrees_0 = ba_model(n, 3, tweak=True, p=0.0)
# save_npz('networks/ba_tweak_p00.npz', ba_t_network_0)


# print(network)

# freq = itemfreq(collaboration_degrees)
# # # print(np.log(freq[:, 0]))
# b, m = plot(np.log(freq[:, 0]), np.log(freq[:, 1] / n), 'Degrees')
# print('Slope = ', m)
#
# draw_degree_distribution(n - 1, coo_matrix(network))


# distances = shortest_path(csgraph=collaboration_network, directed=False, unweighted=True)
# shortest_path_dist = np.unique(distances, return_counts=True)
#
# plot(shortest_path_dist[0], shortest_path_dist[1], 'Shortest Path Distribution', best_fit=False)
# print("Average distance: ", distances.mean())


datasets = ['ba_without_tweak.npz',
            'ba_tweak_p08.npz',
            'ba_tweak_p06.npz',
            'ba_tweak_p04.npz',
            'ba_tweak_p02.npz',
            'ba_tweak_p00.npz']

datasets_2 = ['citation.npz',
              'collaboration.npz',
              'email.npz',
              'internet.npz',
              'metabolic.npz',
              'phonecalls.npz',
              'powergrid.npz',
              'protein.npz',
              'www.npz']

path = '/Users/aarash/Files/courses/mcgill_courses/1/network_science/projects/1/ba_networks/'
index_ba = 0
save_path = '/Users/aarash/Files/courses/mcgill_courses/1/network_science/projects/1/figs/Question3/' + datasets_2[
    index_ba] + '/'

if not os.path.exists(save_path):
    os.mkdir(save_path)

a = load_npz(path + datasets_2[index_ba])

print_graph_properties(a, save_path)
