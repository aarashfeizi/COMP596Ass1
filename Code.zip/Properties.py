import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy.polynomial.polynomial import polyfit
from scipy.sparse import csr_matrix, coo_matrix
from scipy.sparse import diags
from scipy.sparse.csgraph import shortest_path, connected_components
from scipy.sparse.linalg import eigs
from scipy.stats import itemfreq


############################# QUESTION 1


###
# Dataset:  actor.edgelist  Nodes:  702387  Edges:  29397908  Mean K:  41.85428830544984
# Dataset:  citation.edgelist  Nodes:  449672  Edges:  4689361  Mean K:  10.428403369567151
# Dataset:  collaboration.edgelist  Nodes:  23132  Edges:  93439  Mean K:  4.039382673352931
# Dataset:  email.edgelist  Nodes:  57193  Edges:  103083  Mean K:  1.8023709195181228
# Dataset:  internet.edgelist  Nodes:  192243  Edges:  609066  Mean K:  3.168208985502723
# Dataset:  metabolic.edgelist  Nodes:  1038  Edges:  5802  Mean K:  5.589595375722543
# Dataset:  phonecalls.edgelist  Nodes:  36594  Edges:  91826  Mean K:  2.5093184675083346
# Dataset:  powergrid.edgelist  Nodes:  4940  Edges:  6594  Mean K:  1.3348178137651823
# Dataset:  protein.edgelist  Nodes:  2017  Edges:  2705  Mean K:  1.3411006445215667
# Dataset:  www.edgelist  Nodes:  325728  Edges:  1469679  Mean K:  4.511982390215149
###


def save_plot(plt, path):
    plt.savefig(path, dpi=100)
    return True


def get_connected_and_spectral_gap(eigenvalues, tol):
    eigenvalues = sorted(eigenvalues)
    connected_components = 0
    for e in eigenvalues:
        if abs(e - 0) < tol:
            connected_components += 1
            continue
        return connected_components, e

    print("ERROR, SHOULD NOT BE HERE")
    return -1, -1


def get_spectral_gap(degrees, csr_adj_mat, connected_components=1):
    laplacian = diags(degrees, 0) - csr_adj_mat

    vals, vecs = eigs(laplacian.todense(), k=connected_components + 1, which='SM')

    return vals[connected_components]


def get_eigen(degrees, csr_adj_mat):
    laplacian = diags(degrees, 0) - csr_adj_mat
    vals, vecs = np.linalg.eig(laplacian.todense())
    # vals, vecs = eigs(laplacian.todense(), k=connected_components + 1, which='SM')

    # print('cc equals=  ', connected_components)
    # print(vals)
    # print(vals.shape)

    return vals, vecs


def get_simple_graph(csr_graph):
    coo_graph = coo_matrix(csr_graph)

    rows = []
    cols = []

    for i in range(len(coo_graph.row)):
        row = coo_graph.row[i]
        col = coo_graph.col[i]
        if row != col:
            rows.append(row)
            cols.append(col)

    cols = np.array(cols)
    rows = np.array(rows)
    ones = np.ones(len(rows))

    nodes = max(rows.max(), cols.max())

    graph = csr_matrix((ones, (rows, cols)), shape=(nodes + 1, nodes + 1))

    return graph


def convert_to_csr(data):
    ones = np.ones_like(data[:][0])
    nodes1 = max(data[:][1])
    nodes2 = max(data[:][0])
    nodes = max(nodes1, nodes2)
    graph = csr_matrix((ones, (data[:][0], data[:][1])), shape=(nodes + 1, nodes + 1))

    graph.sum_duplicates()

    graph = get_simple_graph(graph)

    return graph


def get_nodes(coo_graph):
    nodes1 = max(coo_graph.col)
    nodes2 = max(coo_graph.row)

    return max(nodes1, nodes2)


def get_undirected_adjacency_mat(csr):
    cs_mat = csr.toarray()
    cs_mat_xdim = cs_mat.shape[1]
    cs_mat_ydim = cs_mat.shape[0]

    diff = cs_mat_xdim - cs_mat_ydim

    zeros = np.array([0 for i in range(cs_mat_xdim)])
    zeros = zeros.reshape([1, cs_mat_xdim])

    for i in range(diff):
        cs_mat = np.concatenate((cs_mat, zeros), axis=0)

    transpose = np.transpose(cs_mat)

    # generate graph with no self-loops

    np.fill_diagonal(transpose, 0)
    np.fill_diagonal(cs_mat, 0)

    a_mat = cs_mat + transpose

    return a_mat


def return_adj_csr(n, row_b, col_b, data_b):  # for UNDIRECTED
    row = np.concatenate((row_b, col_b))
    col = np.concatenate((col_b, row_b))
    data = np.concatenate((data_b, data_b))
    #
    # print(len(row))
    # print(len(col))
    # print(len(data))

    mat = csr_matrix((data, (row, col)), shape=(n + 1, n + 1))
    # print('please done')

    return mat


def plot(x, y, name, best_fit=True, save_path=''):
    fig, ax = plt.subplots()
    b = 0
    m = 0
    ax.scatter(x, y)
    if best_fit:
        b, m = polyfit(x, y, 1)
        plt.plot(x, b + m * x, '-')
    # plt.legend
    plt.title(name)
    ax.text(0.05, 0.95, 'Slope = ' + str(m), transform=ax.transAxes)
    # input()
    save_plot(plt, save_path + name + '.png')
    plt.show()
    # input()
    return b, m


def read_data(path):
    data = pd.read_csv(path, sep="\t", header=None)
    return data
    # np.genfromtxt(path, dtype=[('from', np.intp), ('to', np.intp)])


def draw_degree_distribution(n, coo, save_path):
    degrees = np.array([0 for i in range(n + 1)])
    for index in coo.col:
        degrees[index] += 1
    for index in coo.row:
        degrees[index] += 1
    print('min degree: ', min(degrees))
    print('max degree: ', max(degrees))

    freq = itemfreq(degrees)
    # # print(np.log(freq[:, 0]))
    b, m = plot(np.log(freq[:, 0]), np.log(freq[:, 1]), 'Degrees', save_path=save_path)
    # plt.hist2d(degrees)
    # plt.title("Degrees Distribution")
    print('Slope = ', m)
    return degrees


def dataset_info(path, datasets):
    for dataset in datasets:
        data = read_data(path + dataset + '.txt')
        # print(data.shape)
        data_graph = convert_to_csr(data)
        data_graph = coo_matrix(data_graph)
        print('Dataset: ', dataset,
              ' Nodes: ', get_nodes(data_graph),
              ' Edges: ', data_graph.col.shape[0],
              ' Mean K: ', data_graph.col.shape[0] / get_nodes(data_graph))


def print_graph_properties(csr_graph, save_path):
    coo_graph = coo_matrix(csr_graph)

    nodes = get_nodes(coo_graph)

    ######### a ########### degree distribution

    degrees = draw_degree_distribution(nodes, coo_graph, save_path)

    ######### b ########### clustering coefficient

    ##
    # print(nodes)
    csr_adj_mat = return_adj_csr(nodes, coo_graph.row, coo_graph.col, coo_graph.data)
    # print('done')
    csr_adj_mat2 = csr_adj_mat.dot(csr_adj_mat)
    # print('done')
    csr_adj_mat3 = csr_adj_mat2.dot(csr_adj_mat)
    # print('done')
    adj_mat3_diag = csr_adj_mat3.diagonal()
    adj_mat2_diag = csr_adj_mat2.diagonal()

    denominator = degrees * (degrees - 1)
    denominator[denominator <= 0] = 1

    cc = adj_mat3_diag / denominator
    cc_mean = cc.mean()
    print("Average Clustering Coefficient: ", cc_mean)

    print(cc)
    cc_flat = cc.flatten()
    # freq = itemfreq(cc)
    # b, m = plot(freq[1:, 0], freq[1:, 1], 'Clustering Coefficients')  # todo without 0
    fig, ax = plt.subplots()
    ax.hist(cc_flat, bins=45)
    plt.title('Clustering Coefficient Distribution')
    ax.text(0.05, 0.95, 'Average CC = ' + str(cc_mean), transform=ax.transAxes)
    name = 'ClusteringCoefficientDistribution'
    save_plot(plt, save_path + name + '.png')
    plt.show()

    cc_flat_without_zero = np.delete(cc_flat, np.where(cc_flat == 0))

    fig, ax = plt.subplots()
    ax.hist(cc_flat_without_zero, bins=45)
    plt.title('Clustering Coefficient Distribution (without zero)')
    ax.text(0.05, 0.95, 'Average CC = ' + str(cc_mean), transform=ax.transAxes)
    name = 'ClusteringCoefficientDistribution(withoutZero)'
    save_plot(plt, save_path + name + '.png')
    plt.show()

    ######### c ########### shortest_path

    distances = shortest_path(csgraph=csr_graph, directed=False, unweighted=True)
    shortest_path_dist = np.unique(distances, return_counts=True)

    fig, ax = plt.subplots()
    ax.hist(distances.flatten()[distances.flatten() != np.inf], bins=45)
    plt.title('Shortest Path Distribution')
    ax.text(0.05, 0.95, "Average Distance: " + str(distances.mean()), transform=ax.transAxes)
    name = 'ShortestPathDistribution'
    save_plot(plt, save_path + name + '.png')
    plt.show()
    print("Average distance: ", distances.mean())

    ######### d ########### number of connected components

    no_connected_components, labels = connected_components(csr_graph)

    nodes_count_each_component = np.unique(labels, return_counts=True)[1]
    nodes_in_gcc = nodes_count_each_component.max()
    print("Number of connected components: ", no_connected_components, " Nodes in GCC:", nodes_in_gcc)

    ######### e ########### eigenvalue distribution & Spectral Gap

    eigenvalues, eigenvectors = get_eigen(degrees, csr_adj_mat)

    print("Eigenvalues calculated!")

    eigenvalue_freq = np.unique(eigenvalues, return_counts=True)

    spectral_gap = get_spectral_gap(degrees, csr_adj_mat)
    print("Spectral Gap = ", spectral_gap)

    fig, ax = plt.subplots()
    ax.hist(eigenvalues, bins=45)
    plt.title('Eigenvalues Distribution')
    ax.text(0.35, 0.75, "Spectral Gap = " + str(spectral_gap) +
            "\nNumber of connected components: " + str(no_connected_components) +
            "\nNodes in GCC:" + str(nodes_in_gcc) +
            "\nPortion of nodes in GCC: " + str(100 * nodes_in_gcc / (nodes + 1)) + "%",
            transform=ax.transAxes)
    name = 'EigenvaluesDistribution'
    save_plot(plt, save_path + name + '.png')
    plt.show()

    ######### f ########### degree correlations
    print(degrees)
    print(coo_graph.row)
    print(coo_graph.col)

    fig, ax = plt.subplots()
    ax.hist2d(degrees[coo_graph.row], degrees[coo_graph.col], bins=45, cmap='Blues')
    # cb = plt.colorbar()
    plt.title('Degree Correlation')
    name = 'DegreeCorrelation'
    corr = np.correlate(degrees[coo_graph.row], degrees[coo_graph.col])
    ax.text(0.05, 0.95, "Degree Correlation: " + str(corr), transform=ax.transAxes)
    save_plot(plt, save_path + name + '.png')
    plt.show()

    ######### g ########### degree-clustering coefficient relation
    print(degrees.shape)
    print(cc.shape)

    fig, ax = plt.subplots()
    ax.hist2d(degrees, cc, bins=10, cmap='Blues')
    corr = np.correlate(degrees, cc)
    name = 'DegreeClustering'
    plt.xlabel('Degrees')
    plt.ylabel('Clustering Coefficient')
    plt.title('Degree vs. Clustering')
    ax.text(0.05, 0.95, "Degree and Clustering Coefficient Correlation: " + str(corr), transform=ax.transAxes)
    save_plot(plt, save_path + name + '.png')
    plt.show()


datasets = ['actor.edgelist',
            'citation.edgelist',
            'collaboration.edgelist',
            'email.edgelist',
            'internet.edgelist',
            'metabolic.edgelist',
            'phonecalls.edgelist',
            'powergrid.edgelist',
            'protein.edgelist',
            'www.edgelist']

# dataset_info(path, datasets)
# input()


############
# index = 9
# path = '/Users/aarash/Files/courses/mcgill_courses/1/network_science/datasets/networks/'
# save_path = '/Users/aarash/Files/courses/mcgill_courses/1/network_science/projects/1/figs/Question1/' + datasets[index] + '/'
# if not os.path.exists(save_path):
#     os.mkdir(save_path)
# data = read_data(path + datasets[index] + '.txt')
# csr_graph = convert_to_csr(data)  # also makes the graph simple
# print_graph_properties(csr_graph, save_path)
#
#
#
